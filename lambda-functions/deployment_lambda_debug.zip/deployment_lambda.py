import json
import boto3
import logging
import uuid
from datetime import datetime
import os

os.environ['AWS_ACCOUNT_ID'] = os.environ.get('AWS_ACCOUNT_ID', '123456789012')

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ecs_client = boto3.client('ecs')
codepipeline_client = boto3.client('codepipeline')
cloudformation_client = boto3.client('cloudformation')
dynamodb = boto3.resource('dynamodb')

def handler(event, context):
    """
    Enhanced Deployment Lambda function
    Handles deploy/rollback/update_config methods for static and dynamic services
    """
    try:
        # Debug logging
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Parse deployment request - Handle both API Gateway and Lambda Function URL
        # Lambda Function URL format
        if 'requestContext' in event and 'http' in event['requestContext']:
            http_method = event['requestContext']['http']['method']
            path = event.get('rawPath', '')
        else:
            # API Gateway format
            http_method = event.get('httpMethod', 'POST')
            path = event.get('path', '')
        
        logger.info(f"HTTP Method: {http_method}, Path: {path}")
        
        # Route based on API Gateway path
        if path.endswith('/deploy'):
            method = 'deploy'
        elif path.endswith('/delete'):
            method = 'delete'
        elif path.endswith('/status'):
            method = 'get_status'
        elif path.endswith('/rollback'):
            method = 'rollback'
        else:
            method = 'deploy'  # Default to deploy
        
        # Parse body for parameters
        raw_body = event.get('body', '{}')
        if raw_body:
            # Lambda Function URL might have base64 encoded body
            if event.get('isBase64Encoded', False):
                import base64
                raw_body = base64.b64decode(raw_body).decode('utf-8')
            body = json.loads(raw_body)
        else:
            body = {}
        logger.info(f"Parsed body: {body}")
        
        # Extract parameters with better error handling
        user_id = None
        project_id = None
        service_id = None
        
        if http_method == 'GET':
            # For GET requests, get parameters from query string
            query_params = event.get('queryStringParameters') or {}
            user_id = query_params.get('user_id')
            project_id = query_params.get('project_id')
            service_id = query_params.get('service_id')
        else:
            # For POST requests, get from body
            user_id = body.get('user_id')
            project_id = body.get('project_id')
            service_id = body.get('service_id')
        
        # Convert to string if not None
        if user_id is not None:
            user_id = str(user_id)
        if project_id is not None:
            project_id = str(project_id)
        if service_id is not None:
            service_id = str(service_id)
        
        logger.info(f"Extracted params - user_id: {user_id}, project_id: {project_id}, service_id: {service_id}")
        
        # Temporary test response to debug
        try:
            debug_response = {
                'debug': 'test response',
                'event_keys': list(event.keys()) if event else [],
                'http_method': http_method,
                'path': path,
                'raw_body': str(event.get('body', 'NO_BODY'))[:500],  # Limit length
                'parsed_body': body,
                'user_id': user_id,
                'project_id': project_id,
                'service_id': service_id,
                'service_type': body.get('service_type') if body else None
            }
            return {
                'statusCode': 200,
                'body': json.dumps(debug_response)
            }
        except Exception as debug_error:
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'debug_error': str(debug_error),
                    'event_type': type(event).__name__,
                    'has_body': 'body' in event if event else False
                })
            }
        
        service_type = body.get('service_type')  # "static" or "dynamic"
        runtime = body.get('runtime')
        build_commands = body.get('build_commands', [])
        start_command = body.get('start_command')
        dockerfile = body.get('dockerfile')
        source_bucket = os.environ.get('SOURCE_BUCKET_NAME', 'haifu-source-snapshots')
        
        # Additional fields for static/dynamic services
        build_output_dir = body.get('build_output_dir', 'dist')
        node_version = body.get('node_version', '18')
        
        # Set default runtime for static services if not provided
        if service_type == 'static' and not runtime:
            runtime = f'nodejs{node_version}'
        
        # Resource specifications
        cpu = body.get('cpu', 256)  # CPU units (256, 512, 1024, 2048, 4096)
        memory = body.get('memory', 512)  # Memory in MB (512, 1024, 2048, 4096, 8192)
        port = body.get('port', 80)  # Container port
        env_vars = body.get('environment_variables', [])  # [{"name": "KEY", "value": "VALUE"}]
        
        # Auto-scaling specifications
        min_capacity = body.get('min_capacity', 1)
        max_capacity = body.get('max_capacity', 10)
        cpu_target_value = body.get('cpu_target_value', 70)  # CPU utilization target %
        
        # Generate deployment ID if not provided
        deployment_id = body.get('deployment_id', str(uuid.uuid4()))
        service_name = body.get('service_name', f'user-{user_id}-project-{project_id}-service-{service_id}')
        
        if not user_id or not project_id or not service_id:
            missing_params = []
            if not user_id: missing_params.append('user_id')
            if not project_id: missing_params.append('project_id')
            if not service_id: missing_params.append('service_id')
            
            logger.error(f"Missing required parameters: {missing_params}")
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': f'Missing required parameters: {", ".join(missing_params)}',
                    'received_params': {
                        'user_id': user_id,
                        'project_id': project_id,
                        'service_id': service_id,
                        'service_type': service_type
                    }
                })
            }
        
        if not service_type:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'service_type is required'})
            }
        
        # Validate CPU/Memory combinations for Fargate
        if service_type == 'dynamic' and method == 'deploy':
            if not validate_fargate_specs(cpu, memory):
                return {
                    'statusCode': 400,
                    'body': json.dumps({
                        'error': 'Invalid CPU/Memory combination for Fargate',
                        'valid_combinations': get_valid_fargate_specs()
                    })
                }
        
        # Update deployment status
        update_deployment_status(deployment_id, 'DEPLOYING', f'{method} {service_type} deployment', user_id, project_id, service_id, service_type)
        
        # Route to appropriate method handler
        if method == 'deploy':
            if service_type == 'static':
                result = deploy_static_service(deployment_id, user_id, project_id, service_id, service_name, build_commands, source_bucket, build_output_dir, node_version)
            elif service_type == 'dynamic':
                result = deploy_dynamic_service(
                    deployment_id, user_id, project_id, service_id, service_name, runtime, 
                    build_commands, start_command, dockerfile, source_bucket, cpu, memory, port, env_vars,
                    min_capacity, max_capacity, cpu_target_value
                )
            else:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'Invalid service_type'})
                }
        elif method == 'delete':
            result = delete_service(user_id, project_id, service_id)
        elif method == 'rollback':
            result = rollback_service(deployment_id, service_name, service_type)
        elif method == 'update_config':
            result = update_service_config(deployment_id, service_name, service_type, body)
        elif method == 'get_status':
            result = get_service_status(user_id, project_id, service_id)
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid method. Must be deploy/delete/rollback/update_config/get_status'})
            }
        
        if result['success']:
            update_deployment_status(deployment_id, 'SUCCESS', 'Deployment completed')
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'deployment_id': deployment_id,
                    'service_name': service_name,
                    'service_type': service_type,
                    'status': 'SUCCESS',
                    **result['data']
                })
            }
        else:
            update_deployment_status(deployment_id, 'FAILED', result['error'])
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'deployment_id': deployment_id,
                    'status': 'FAILED',
                    'error': result['error']
                })
            }
            
    except Exception as e:
        logger.error(f"Deployment error: {str(e)}")
        if 'deployment_id' in locals():
            update_deployment_status(deployment_id, 'FAILED', str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def deploy_static_service(deployment_id, user_id, project_id, service_id, service_name, build_commands, source_bucket, build_output_dir='dist', node_version='18'):
    """
    Deploy static service using S3 + CloudFront via CloudFormation
    Source files from S3: users/{user_id}/{project_id}/{service_id}/
    """
    try:
        stack_name = f'haifu-static-{service_name}'
        
        # CloudFormation template for static deployment
        template = {
            "AWSTemplateFormatVersion": "2010-09-09",
            "Resources": {
                "S3Bucket": {
                    "Type": "AWS::S3::Bucket",
                    "Properties": {
                        "BucketName": f"haifu-static-{service_name}-{deployment_id[:8]}",
                        "WebsiteConfiguration": {
                            "IndexDocument": "index.html",
                            "ErrorDocument": "error.html"
                        },
                        "PublicAccessBlockConfiguration": {
                            "BlockPublicAcls": False,
                            "BlockPublicPolicy": False,
                            "IgnorePublicAcls": False,
                            "RestrictPublicBuckets": False
                        }
                    }
                },
                "CloudFrontDistribution": {
                    "Type": "AWS::CloudFront::Distribution",
                    "Properties": {
                        "DistributionConfig": {
                            "Origins": [{
                                "DomainName": {"Fn::GetAtt": ["S3Bucket", "RegionalDomainName"]},
                                "Id": "S3Origin",
                                "S3OriginConfig": {}
                            }],
                            "DefaultCacheBehavior": {
                                "TargetOriginId": "S3Origin",
                                "ViewerProtocolPolicy": "redirect-to-https",
                                "AllowedMethods": ["GET", "HEAD"],
                                "CachedMethods": ["GET", "HEAD"],
                                "ForwardedValues": {"QueryString": False}
                            },
                            "Enabled": True,
                            "DefaultRootObject": "index.html"
                        }
                    }
                }
            },
            "Outputs": {
                "BucketName": {"Value": {"Ref": "S3Bucket"}},
                "CloudFrontURL": {"Value": {"Fn::GetAtt": ["CloudFrontDistribution", "DomainName"]}}
            }
        }
        
        # Create CloudFormation stack
        cloudformation_client.create_stack(
            StackName=stack_name,
            TemplateBody=json.dumps(template),
            Capabilities=['CAPABILITY_IAM']
        )
        
        # Build static files if build commands provided
        source_key = f'users/{user_id}/{project_id}/{service_id}/'
        deploy_bucket = f"haifu-static-{service_name}-{deployment_id[:8]}"
        
        if build_commands:
            # Build static files using CodeBuild
            build_static_files(source_bucket, source_key, deploy_bucket, build_commands, build_output_dir, node_version)
        else:
            # Direct copy without build
            copy_s3_files(source_bucket, source_key, deploy_bucket)
        
        return {
            'success': True,
            'data': {
                'stack_name': stack_name,
                'deployment_type': 'static'
            }
        }
        
    except Exception as e:
        logger.error(f"Static deployment error: {str(e)}")
        return {'success': False, 'error': str(e)}

def deploy_dynamic_service(deployment_id, user_id, project_id, service_id, service_name, runtime, build_commands, start_command, dockerfile, source_bucket, cpu, memory, port, env_vars, min_capacity, max_capacity, cpu_target_value):
    """
    Deploy dynamic service to ECS Fargate with auto-scaling
    Source files from S3: users/{user_id}/{project_id}/{service_id}/
    """
    try:
        cluster_name = 'haifu-dev-user-services'
        
        # Create CloudWatch log group
        create_log_group(service_name)
        
        # Create ECR repository
        create_ecr_repository(service_name)
        
        task_def_response = ecs_client.register_task_definition(
            family=f'haifu-dev-{service_name}',
            networkMode='awsvpc',
            requiresCompatibilities=['FARGATE'],
            cpu=str(cpu),
            memory=str(memory),
            executionRoleArn=f'arn:aws:iam::{context.invoked_function_arn.split(":")[4]}:role/haifu-dev-ecs-execution-role',
            containerDefinitions=[{
                'name': service_name,
                'image': f'{context.invoked_function_arn.split(":")[4]}.dkr.ecr.ap-northeast-2.amazonaws.com/haifu-dev-{service_name}:latest',
                'cpu': cpu,
                'memory': memory,
                'essential': True,
                'portMappings': [{'containerPort': port, 'protocol': 'tcp'}],
                'environment': [
                    {'name': 'START_COMMAND', 'value': start_command or 'npm start'},
                    {'name': 'RUNTIME', 'value': runtime}
                ] + env_vars,
                'logConfiguration': {
                    'logDriver': 'awslogs',
                    'options': {
                        'awslogs-group': f'/ecs/haifu-dev-{service_name}',
                        'awslogs-region': 'ap-northeast-2',
                        'awslogs-stream-prefix': 'ecs'
                    }
                }
            }]
        )
        
        # Create ECS service with auto-scaling
        service_response = ecs_client.create_service(
            cluster=cluster_name,
            serviceName=f'haifu-dev-{service_name}',
            taskDefinition=task_def_response['taskDefinition']['taskDefinitionArn'],
            desiredCount=1,
            launchType='FARGATE',
            networkConfiguration={
                'awsvpcConfiguration': {
                    'subnets': get_private_subnets(),
                    'securityGroups': [get_ecs_security_group()],
                    'assignPublicIp': 'DISABLED'
                }
            },
            loadBalancers=[{
                'targetGroupArn': get_target_group_arn(service_name),
                'containerName': service_name,
                'containerPort': port
            }]
        )
        
        # Setup auto-scaling with custom specifications
        setup_auto_scaling(service_name, cluster_name, min_capacity, max_capacity, cpu_target_value)
        
        # Build and push Docker image from S3 source
        source_key = f'users/{user_id}/{project_id}/{service_id}/'
        build_and_push_image(source_bucket, source_key, service_name, runtime, build_commands, start_command, dockerfile)
        
        return {
            'success': True,
            'data': {
                'service_arn': service_response['service']['serviceArn'],
                'deployment_type': 'dynamic',
                'runtime': runtime
            }
        }
        
    except Exception as e:
        logger.error(f"Dynamic deployment error: {str(e)}")
        return {'success': False, 'error': str(e)}

def rollback_service(deployment_id, service_name, service_type):
    """Rollback service to previous version"""
    try:
        if service_type == 'dynamic':
            # ECS service rollback
            ecs_client.update_service(
                cluster='haifu-dev-user-services',
                service=f'haifu-dev-{service_name}',
                taskDefinition=get_previous_task_definition(service_name)
            )
        else:
            # Static rollback via CloudFormation
            cloudformation_client.cancel_update_stack(
                StackName=f'haifu-static-{service_name}'
            )
        
        return {'success': True, 'data': {'action': 'rollback'}}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def update_service_config(deployment_id, service_name, service_type, config):
    """Update service configuration"""
    try:
        # Update environment variables, scaling, etc.
        return {'success': True, 'data': {'action': 'config_updated'}}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def get_previous_task_definition(service_name):
    """Get previous task definition ARN for rollback"""
    response = ecs_client.list_task_definitions(
        familyPrefix=f'haifu-dev-{service_name}',
        status='ACTIVE',
        sort='DESC',
        maxResults=2
    )
    return response['taskDefinitionArns'][1] if len(response['taskDefinitionArns']) > 1 else response['taskDefinitionArns'][0]ent)
        
        return {
            'success': True,
            'data': {
                'service_arn': service_response['service']['serviceArn'],
                'deployment_type': 'dynamic',
                'runtime': runtime
            }
        }
        
    except Exception as e:
        logger.error(f"Dynamic deployment error: {str(e)}")
        return {'success': False, 'error': str(e)}

def get_resource_specs(runtime):
    """Get CPU and memory specs based on runtime"""
    specs = {
        'nodejs18': (256, 512),
        'python3.11': (256, 512),
        'java17': (512, 1024),
        'go1.21': (256, 512)
    }
    return specs.get(runtime, (256, 512))

def setup_auto_scaling(service_name, cluster_name, min_capacity=1, max_capacity=10, cpu_target_value=70):
    """Setup auto-scaling for ECS service with custom specifications"""
    autoscaling_client = boto3.client('application-autoscaling')
    
    # Register scalable target
    autoscaling_client.register_scalable_target(
        ServiceNamespace='ecs',
        ResourceId=f'service/{cluster_name}/haifu-dev-{service_name}',
        ScalableDimension='ecs:service:DesiredCount',
        MinCapacity=min_capacity,
        MaxCapacity=max_capacity
    )
    
    # Create scaling policy
    autoscaling_client.put_scaling_policy(
        PolicyName=f'{service_name}-cpu-scaling',
        ServiceNamespace='ecs',
        ResourceId=f'service/{cluster_name}/haifu-dev-{service_name}',
        ScalableDimension='ecs:service:DesiredCount',
        PolicyType='TargetTrackingScaling',
        TargetTrackingScalingPolicyConfiguration={
            'TargetValue': float(cpu_target_value),
            'PredefinedMetricSpecification': {
                'PredefinedMetricType': 'ECSServiceAverageCPUUtilization'
            }
        }
    )

def validate_fargate_specs(cpu, memory):
    """Validate CPU/Memory combination for AWS Fargate"""
    valid_combinations = {
        256: [512, 1024, 2048],
        512: [1024, 2048, 3072, 4096],
        1024: [2048, 3072, 4096, 5120, 6144, 7168, 8192],
        2048: [4096, 5120, 6144, 7168, 8192, 9216, 10240, 11264, 12288, 13312, 14336, 15360, 16384],
        4096: [8192, 9216, 10240, 11264, 12288, 13312, 14336, 15360, 16384, 17408, 18432, 19456, 20480, 21504, 22528, 23552, 24576, 25600, 26624, 27648, 28672, 29696, 30720]
    }
    
    return cpu in valid_combinations and memory in valid_combinations[cpu]

def get_valid_fargate_specs():
    """Get valid CPU/Memory combinations for Fargate"""
    return {
        "256": [512, 1024, 2048],
        "512": [1024, 2048, 3072, 4096],
        "1024": [2048, 3072, 4096, 5120, 6144, 7168, 8192],
        "2048": "4096-16384 (increments of 1024)",
        "4096": "8192-30720 (increments of 1024)"
    }



def get_private_subnets():
    """Get private subnet IDs from SSM Parameter Store"""
    try:
        ssm_client = boto3.client('ssm')
        response = ssm_client.get_parameter(Name='/haifu/vpc/private-subnets')
        return response['Parameter']['Value'].split(',')
    except:
        # Fallback to environment variable or default
        return os.environ.get('PRIVATE_SUBNETS', 'subnet-0123456789abcdef0,subnet-0987654321fedcba0').split(',')

def get_ecs_security_group():
    """Get ECS security group ID from SSM Parameter Store"""
    try:
        ssm_client = boto3.client('ssm')
        response = ssm_client.get_parameter(Name='/haifu/vpc/ecs-security-group')
        return response['Parameter']['Value']
    except:
        # Fallback to environment variable
        return os.environ.get('ECS_SECURITY_GROUP', 'sg-0123456789abcdef0')

def get_target_group_arn(service_name):
    """Create or get target group for the service"""
    try:
        elbv2_client = boto3.client('elbv2')
        
        # Try to find existing target group
        try:
            response = elbv2_client.describe_target_groups(
                Names=[f'haifu-{service_name}']
            )
            return response['TargetGroups'][0]['TargetGroupArn']
        except:
            pass
        
        # Create new target group
        vpc_id = get_vpc_id()
        response = elbv2_client.create_target_group(
            Name=f'haifu-{service_name}',
            Protocol='HTTP',
            Port=80,
            VpcId=vpc_id,
            TargetType='ip',
            HealthCheckPath='/health',
            HealthCheckProtocol='HTTP'
        )
        
        target_group_arn = response['TargetGroups'][0]['TargetGroupArn']
        
        # Attach to ALB
        attach_to_alb(target_group_arn, service_name)
        
        return target_group_arn
        
    except Exception as e:
        logger.error(f"Target group creation error: {str(e)}")
        raise e

def get_vpc_id():
    """Get VPC ID from SSM Parameter Store"""
    try:
        ssm_client = boto3.client('ssm')
        response = ssm_client.get_parameter(Name='/haifu/vpc/vpc-id')
        return response['Parameter']['Value']
    except:
        return os.environ.get('VPC_ID', 'vpc-0123456789abcdef0')

def attach_to_alb(target_group_arn, service_name):
    """Attach target group to ALB"""
    try:
        elbv2_client = boto3.client('elbv2')
        
        # Get ALB listener ARN
        alb_arn = get_alb_arn()
        listeners = elbv2_client.describe_listeners(LoadBalancerArn=alb_arn)
        listener_arn = listeners['Listeners'][0]['ListenerArn']
        
        # Create listener rule
        elbv2_client.create_rule(
            ListenerArn=listener_arn,
            Priority=get_next_priority(listener_arn),
            Conditions=[
                {
                    'Field': 'path-pattern',
                    'Values': [f'/{service_name}*']
                }
            ],
            Actions=[
                {
                    'Type': 'forward',
                    'TargetGroupArn': target_group_arn
                }
            ]
        )
        
    except Exception as e:
        logger.error(f"ALB attachment error: {str(e)}")

def get_alb_arn():
    """Get ALB ARN from SSM Parameter Store"""
    try:
        ssm_client = boto3.client('ssm')
        response = ssm_client.get_parameter(Name='/haifu/alb/arn')
        return response['Parameter']['Value']
    except:
        return os.environ.get('ALB_ARN', 'arn:aws:elasticloadbalancing:ap-northeast-2:123456789012:loadbalancer/app/haifu-dev-alb/1234567890123456')

def get_next_priority(listener_arn):
    """Get next available priority for ALB listener rule"""
    try:
        elbv2_client = boto3.client('elbv2')
        rules = elbv2_client.describe_rules(ListenerArn=listener_arn)
        priorities = [int(rule['Priority']) for rule in rules['Rules'] if rule['Priority'] != 'default']
        return max(priorities) + 1 if priorities else 100
    except:
        return 100

def delete_service(user_id, project_id, service_id):
    """
    Delete service and all associated resources
    """
    try:
        service_name = f'user-{user_id}-project-{project_id}-service-{service_id}'
        
        # Get service info from DynamoDB
        table = dynamodb.Table('haifu-dev-deployment-status')
        response = table.scan(
            FilterExpression='service_id = :sid',
            ExpressionAttributeValues={':sid': service_id}
        )
        
        if not response['Items']:
            return {'success': False, 'error': 'Service not found'}
        
        service_info = response['Items'][0]
        service_type = service_info.get('service_type')
        
        if service_type == 'dynamic':
            # Delete ECS service
            ecs_client.delete_service(
                cluster='haifu-dev-user-services',
                service=service_name,
                force=True
            )
            
            # Delete task definition (mark as INACTIVE)
            ecs_client.deregister_task_definition(
                taskDefinition=f'haifu-dev-{service_name}'
            )
        else:
            # Delete CloudFormation stack for static service
            cloudformation_client.delete_stack(
                StackName=f'haifu-static-{service_name}'
            )
        
        # Delete CodePipeline
        codepipeline_client.delete_pipeline(
            name=f'{service_name}-pipeline'
        )
        
        # Update DynamoDB status
        table.update_item(
            Key={'deployment_id': service_info['deployment_id']},
            UpdateExpression='SET #status = :status, #message = :message',
            ExpressionAttributeNames={'#status': 'status', '#message': 'message'},
            ExpressionAttributeValues={':status': 'DELETED', ':message': 'Service deleted'}
        )
        
        return {'success': True, 'data': {'action': 'deleted', 'service_name': service_name}}
        
    except Exception as e:
        logger.error(f"Delete service error: {str(e)}")
        return {'success': False, 'error': str(e)}

def get_service_status(user_id, project_id, service_id):
    """
    Get current service status and deployment info
    """
    try:
        service_name = f'user-{user_id}-project-{project_id}-service-{service_id}'
        
        # Get from DynamoDB
        table = dynamodb.Table('haifu-dev-deployment-status')
        response = table.scan(
            FilterExpression='service_id = :sid',
            ExpressionAttributeValues={':sid': service_id}
        )
        
        if not response['Items']:
            return {'success': False, 'error': 'Service not found'}
        
        service_info = response['Items'][0]
        
        # Get pipeline status
        pipeline_name = f'{service_name}-pipeline'
        try:
            pipeline_status = codepipeline_client.get_pipeline_state(
                name=pipeline_name
            )
            service_info['pipeline_status'] = pipeline_status
        except:
            service_info['pipeline_status'] = 'NOT_FOUND'
        
        return {'success': True, 'data': service_info}
        
    except Exception as e:
        logger.error(f"Get service status error: {str(e)}")
        return {'success': False, 'error': str(e)}

def copy_s3_files(source_bucket, source_key, dest_bucket):
    """
    Copy files from source S3 location to deployment S3 bucket
    """
    try:
        s3_client = boto3.client('s3')
        
        # List all objects in source location
        response = s3_client.list_objects_v2(
            Bucket=source_bucket,
            Prefix=source_key
        )
        
        if 'Contents' not in response:
            raise Exception(f"No files found in {source_bucket}/{source_key}")
        
        # Copy each file to destination bucket
        for obj in response['Contents']:
            source_file = obj['Key']
            dest_file = source_file.replace(source_key, '')
            
            s3_client.copy_object(
                CopySource={'Bucket': source_bucket, 'Key': source_file},
                Bucket=dest_bucket,
                Key=dest_file
            )
        
        logger.info(f"Copied {len(response['Contents'])} files to {dest_bucket}")
        
    except Exception as e:
        logger.error(f"S3 copy error: {str(e)}")
        raise e

def build_and_push_image(source_bucket, source_key, service_name, runtime, build_commands, start_command, dockerfile):
    """
    Build Docker image from S3 source and push to ECR using CodeBuild
    """
    try:
        codebuild_client = boto3.client('codebuild')
        
        # Create or get CodeBuild project
        project_name = f'haifu-build-{service_name}'
        create_codebuild_project(project_name, service_name, runtime)
        
        # Generate buildspec.yml content
        buildspec = generate_buildspec(runtime, build_commands, start_command, dockerfile)
        
        # Upload buildspec to S3
        s3_client = boto3.client('s3')
        buildspec_key = f'{source_key}buildspec.yml'
        s3_client.put_object(
            Bucket=source_bucket,
            Key=buildspec_key,
            Body=buildspec
        )
        
        # Start CodeBuild
        response = codebuild_client.start_build(
            projectName=project_name,
            sourceLocationOverride=f'{source_bucket}/{source_key}',
            environmentVariablesOverride=[
                {'name': 'SERVICE_NAME', 'value': service_name},
                {'name': 'RUNTIME', 'value': runtime},
                {'name': 'AWS_ACCOUNT_ID', 'value': context.invoked_function_arn.split(':')[4]}
            ]
        )
        
        logger.info(f"CodeBuild started: {response['build']['id']}")
        return response['build']['id']
        
    except Exception as e:
        logger.error(f"Docker build error: {str(e)}")
        raise e

def create_codebuild_project(project_name, service_name, runtime):
    """Create CodeBuild project for Docker image building"""
    try:
        codebuild_client = boto3.client('codebuild')
        
        # Check if project exists
        try:
            codebuild_client.batch_get_projects(names=[project_name])
            return  # Project already exists
        except:
            pass
        
        # Create CodeBuild project
        codebuild_client.create_project(
            name=project_name,
            source={
                'type': 'S3',
                'buildspec': 'buildspec.yml'
            },
            artifacts={
                'type': 'NO_ARTIFACTS'
            },
            environment={
                'type': 'LINUX_CONTAINER',
                'image': 'aws/codebuild/standard:5.0',
                'computeType': 'BUILD_GENERAL1_MEDIUM',
                'privileged': True
            },
            serviceRole=f'arn:aws:iam::{context.invoked_function_arn.split(":")[4]}:role/haifu-dev-codebuild-role'
        )
        
        logger.info(f"Created CodeBuild project: {project_name}")
        
    except Exception as e:
        logger.error(f"CodeBuild project creation error: {str(e)}")

def generate_buildspec(runtime, build_commands, start_command, dockerfile):
    """Generate buildspec.yml for CodeBuild"""
    
    if not dockerfile:
        dockerfile = generate_dockerfile(runtime, start_command, build_commands)
    
    buildspec = f"""
version: 0.2
phases:
  pre_build:
    commands:
      - echo Logging in to Amazon ECR...
      - aws ecr get-login-password --region ap-northeast-2 | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.ap-northeast-2.amazonaws.com
      - REPOSITORY_URI=$AWS_ACCOUNT_ID.dkr.ecr.ap-northeast-2.amazonaws.com/haifu-dev-$SERVICE_NAME
      - IMAGE_TAG=latest
  build:
    commands:
      - echo Build started on `date`
      - echo Building the Docker image...
      - |
        cat > Dockerfile << 'EOF'
{dockerfile}
EOF
      - docker build -t $REPOSITORY_URI:$IMAGE_TAG .
  post_build:
    commands:
      - echo Build completed on `date`
      - echo Pushing the Docker image...
      - docker push $REPOSITORY_URI:$IMAGE_TAG
"""
    
    return buildspec

def create_log_group(service_name):
    """Create CloudWatch log group for ECS service"""
    try:
        logs_client = boto3.client('logs')
        log_group_name = f'/ecs/haifu-dev-{service_name}'
        
        logs_client.create_log_group(
            logGroupName=log_group_name,
            retentionInDays=7
        )
        logger.info(f"Created log group: {log_group_name}")
        
    except logs_client.exceptions.ResourceAlreadyExistsException:
        logger.info(f"Log group already exists: /ecs/haifu-dev-{service_name}")
    except Exception as e:
        logger.error(f"Log group creation error: {str(e)}")

def build_static_files(source_bucket, source_key, deploy_bucket, build_commands, build_output_dir, node_version):
    """Build static files using CodeBuild and deploy to S3"""
    try:
        codebuild_client = boto3.client('codebuild')
        
        # Create CodeBuild project for static build
        project_name = f'haifu-static-build-{deploy_bucket}'
        
        # Generate buildspec for static build
        buildspec = f"""
version: 0.2
phases:
  install:
    runtime-versions:
      nodejs: {node_version}
  pre_build:
    commands:
      - echo Installing dependencies...
  build:
    commands:
{chr(10).join([f'      - {cmd}' for cmd in build_commands])}
  post_build:
    commands:
      - echo Build completed
      - aws s3 sync {build_output_dir}/ s3://{deploy_bucket}/ --delete
"""
        
        # Upload buildspec to S3
        s3_client = boto3.client('s3')
        buildspec_key = f'{source_key}buildspec-static.yml'
        s3_client.put_object(
            Bucket=source_bucket,
            Key=buildspec_key,
            Body=buildspec
        )
        
        # Create temporary CodeBuild project
        codebuild_client.create_project(
            name=project_name,
            source={
                'type': 'S3',
                'location': f'{source_bucket}/{source_key}',
                'buildspec': 'buildspec-static.yml'
            },
            artifacts={
                'type': 'NO_ARTIFACTS'
            },
            environment={
                'type': 'LINUX_CONTAINER',
                'image': 'aws/codebuild/standard:5.0',
                'computeType': 'BUILD_GENERAL1_SMALL'
            },
            serviceRole=f'arn:aws:iam::{context.invoked_function_arn.split(":")[4]}:role/haifu-dev-codebuild-role'
        )
        
        # Start build
        response = codebuild_client.start_build(
            projectName=project_name,
            environmentVariablesOverride=[
                {'name': 'DEPLOY_BUCKET', 'value': deploy_bucket},
                {'name': 'BUILD_OUTPUT_DIR', 'value': build_output_dir}
            ]
        )
        
        logger.info(f"Static build started: {response['build']['id']}")
        
        # Clean up project after build (optional)
        # codebuild_client.delete_project(name=project_name)
        
    except Exception as e:
        logger.error(f"Static build error: {str(e)}")
        # Fallback to direct copy
        copy_s3_files(source_bucket, source_key, deploy_bucket)

def create_ecr_repository(service_name):
    """Create ECR repository for service"""
    try:
        ecr_client = boto3.client('ecr')
        repo_name = f'haifu-dev-{service_name}'
        
        ecr_client.create_repository(
            repositoryName=repo_name,
            imageScanningConfiguration={'scanOnPush': True}
        )
        logger.info(f"Created ECR repository: {repo_name}")
        
    except ecr_client.exceptions.RepositoryAlreadyExistsException:
        logger.info(f"ECR repository already exists: haifu-dev-{service_name}")
    except Exception as e:
        logger.error(f"ECR repository creation error: {str(e)}")

def generate_dockerfile(runtime, start_command, build_commands):
    """
    Generate Dockerfile based on runtime and commands
    """
    base_images = {
        'nodejs18': 'node:18-alpine',
        'python3.11': 'python:3.11-slim',
        'java17': 'openjdk:17-jre-slim',
        'go1.21': 'golang:1.21-alpine'
    }
    
    base_image = base_images.get(runtime, 'node:18-alpine')
    
    dockerfile = f"""FROM {base_image}
WORKDIR /app
COPY . .
"""
    
    # Add build commands
    for cmd in build_commands:
        dockerfile += f"RUN {cmd}\n"
    
    # Add start command
    dockerfile += f"CMD [\"{start_command or 'npm start'}\"]"
    
    return dockerfile

def update_deployment_status(deployment_id, status, message, user_id=None, project_id=None, service_id=None, service_type=None):
    """
    Update deployment status in DynamoDB with enhanced tracking
    """
    try:
        table = dynamodb.Table('haifu-dev-deployment-status')
        item = {
            'deployment_id': deployment_id,
            'status': status,
            'message': message,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        # Add optional fields if provided
        if user_id:
            item['user_id'] = user_id
        if project_id:
            item['project_id'] = project_id
        if service_id:
            item['service_id'] = service_id
        if service_type:
            item['service_type'] = service_type
            
        table.put_item(Item=item)
    except Exception as e:
        logger.error(f"DynamoDB update error: {str(e)}")